package arg.org.centro8.curso.java.club.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import arg.org.centro8.curso.java.club.connectors.Connector;
import arg.org.centro8.curso.java.club.entities.Actividad;
import arg.org.centro8.curso.java.club.enums.Dia;
import arg.org.centro8.curso.java.club.enums.Turno;

public class ActividadRepository {
    private Connection conn = Connector.getConnection();

    public void save(Actividad actividad) {
        if (actividad == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into actividad (nombre,entrenador,DIA,TURNO) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, actividad.getNombre());
            ps.setString(2, actividad.getEntrenador());
            ps.setString(3, actividad.getDia().toString());
            ps.setString(4, actividad.getTurno().toString());
            ps.execute();
            ResultSet ar = ps.getGeneratedKeys();
            if (ar.next())
                actividad.setId(ar.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Actividad> getAll() {
        List<Actividad> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from actividad")) {
            while (rs.next()) {
                list.add(new Actividad(
                        rs.getInt("id"), // id
                        rs.getString("nombre"), // nombre
                        rs.getString("entrenador"), // entrenador 
                        Dia.valueOf(rs.getString("dia")), // dia
                        Turno.valueOf(rs.getString("turno")) // turno
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Actividad getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(new Actividad());
    }

    public List<Actividad>getLikeActividad(String nombre){
        if(nombre==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(c->c.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                    .toList();      //JDK 16 o sup
    }

    public Iterable<Actividad> getLikeNombre(String string) {
        return null;
    }


}
